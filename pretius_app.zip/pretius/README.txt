BUILD: 
run command: 'mvn install'

RUN: 
run created jar from /target directory: java -jar target/pretius-1.0.jar

OUTCOME:
Created directiories are located it 'out' folder which can be found in the root directory.

