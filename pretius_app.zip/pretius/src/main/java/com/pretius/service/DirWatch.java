package com.pretius.service;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;


public class DirWatch {

    private static final String HOME_DIR = "out/HOME";
    private static final String DEV_DIR = "out/DEV";
    private static final String TEST_DIR = "out/TEST";

    private static int countAll = 0;
    private static int countTest = 0;
    private static int countDev = 0;

    public static void watchDirectoryPath() throws IOException, InterruptedException {


        WatchService watchService
                = FileSystems.getDefault().newWatchService();


        FileWriter writer = new FileWriter(HOME_DIR + "/" + "count.txt", false);

        Path path = Paths.get(HOME_DIR);

        path.register(
                watchService,
                StandardWatchEventKinds.ENTRY_CREATE);

        WatchKey key;
        while ((key = watchService.take()) != null) {
            for (WatchEvent<?> event : key.pollEvents()) {
                LocalDateTime time = LocalDateTime.now();
                int hour = time.getHour();
                countAll += event.count();

                String fileName = event.context().toString();
                String extension = getExtension(fileName);

                if (extension.equals("jar")){
                    if (hour % 2 == 0) {
                        move(DEV_DIR, fileName, event.count());

                    } else {
                        move(TEST_DIR, fileName, event.count());
                    }

                }else if(extension.equals("xml")) {
                    move(DEV_DIR, fileName, event.count());
                }

                writer.write("All: " + countAll + " DEV: " + countDev + " TEST: "+ countTest + '\n');
                writer.flush();
            }
            key.reset();
        }
        writer.close();
    }

    private static void move(String destination, String fileName, int count) throws IOException {
        try {
            Files.move(Paths.get(HOME_DIR + "/" + fileName), Paths.get(destination + "/" + fileName));
            countDev += count;
        }catch (FileAlreadyExistsException ex){
            System.out.println(ex.toString());
            File f = new File(HOME_DIR + "/" + fileName);
            f.delete();
            countAll -= count;
        }
    }

    private static String getExtension(String fileName){
        String extension = "";

        int i = fileName.lastIndexOf('.');
        if (i > 0) {
            extension = fileName.substring(i+1);
        }
        return extension;
    }
}
