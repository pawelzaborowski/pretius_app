package com.pretius.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DirCreator {

    public void createDir(String name){

        try{
            Path path = Paths.get("out/" + name);
            Files.createDirectories(path);
        } catch (IOException e) {
            System.err.println("Directory not created" + e.getMessage());
        }
    }

    public void createFile(String name){

        try{
            Path path = Paths.get("out/" + name);
            Files.createFile(path);
        } catch (IOException e) {
            System.err.println("Directory not created" + e.getMessage());
        }
    }
}
