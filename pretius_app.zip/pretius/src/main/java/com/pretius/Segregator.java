package com.pretius;

import com.pretius.service.DirCreator;
import com.pretius.service.DirWatch;

import java.io.IOException;

public class Segregator {

    public static void main(String[] args) {

        DirCreator dirCreator = new DirCreator();
        dirCreator.createDir("HOME");
        dirCreator.createDir("DEV");
        dirCreator.createDir("TEST");
        dirCreator.createFile("HOME/count.txt");

        try {
            DirWatch.watchDirectoryPath();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
